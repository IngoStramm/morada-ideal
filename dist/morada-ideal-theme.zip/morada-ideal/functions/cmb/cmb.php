<?php
if (!mi_check_if_plugin_is_active('cmb2/init.php')) {
    return;
}

require_once 'settings-cmb.php';
require_once 'imoveis-cmb.php';
