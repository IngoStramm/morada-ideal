(() => {
    'use strict';
})();